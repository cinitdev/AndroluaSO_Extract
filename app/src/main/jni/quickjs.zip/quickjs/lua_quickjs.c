#include <stdlib.h>
#include <string.h>
#include "lua.h"
#include "lauxlib.h"
#include "quickjs.h"


static char* captured_cookie_value = NULL;


static JSValue js_dom_set_cookie(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    if (argc > 0) {
        const char *cookie_str = JS_ToCString(ctx, argv[0]);
        if (cookie_str) {
            if (captured_cookie_value) {
                free(captured_cookie_value);
                captured_cookie_value = NULL;
            }
            captured_cookie_value = strdup(cookie_str);
            JS_FreeCString(ctx, cookie_str);
        }
    }
    return JS_UNDEFINED;
}

static JSValue js_dom_dummy_func(JSContext *ctx, JSValueConst this_val, int argc, JSValueConst *argv) {
    return JS_UNDEFINED;
}

static int l_quickjs_eval(lua_State *L) {
    const char *js_code = luaL_checkstring(L, 1);
    const char *host = luaL_optstring(L, 2, "localhost");

    JSRuntime *rt = JS_NewRuntime();
    JSContext *ctx = JS_NewContext(rt);

    if (captured_cookie_value) {
        free(captured_cookie_value);
        captured_cookie_value = NULL;
    }

    JSValue global_obj = JS_GetGlobalObject(ctx);

    JSValue location = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, location, "host", JS_NewString(ctx, host));
    JS_SetPropertyStr(ctx, global_obj, "location", location);

    JSValue document = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, global_obj, "document", document);

    JSValue doc_location = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, doc_location, "reload", JS_NewCFunction(ctx, js_dom_dummy_func, "reload", 0));
    JS_SetPropertyStr(ctx, document, "location", doc_location);
    
    JS_DefineProperty(ctx, document, JS_NewAtom(ctx, "cookie"), JS_UNDEFINED,
                      JS_UNDEFINED,
                      JS_NewCFunction(ctx, js_dom_set_cookie, "set", 1),
                      JS_PROP_WRITABLE | JS_PROP_CONFIGURABLE);

    JSValue result = JS_Eval(ctx, js_code, strlen(js_code), "<eval>", JS_EVAL_TYPE_GLOBAL);

    if (JS_IsException(result)) {
        JSValue exception = JS_GetException(ctx);
        const char *error_str = JS_ToCString(ctx, exception);
        lua_pushnil(L);
        lua_pushstring(L, error_str ? error_str : "Unknown JS exception");
        JS_FreeCString(ctx, error_str);
        JS_FreeValue(ctx, exception);
        JS_FreeValue(ctx, result);
        JS_FreeContext(ctx);
        JS_FreeRuntime(rt);
        return 2;
    }
    JS_FreeValue(ctx, result);

    if (captured_cookie_value) {
        char *start = strstr(captured_cookie_value, "acw_sc__v2=");
        if (start) {
            start += strlen("acw_sc__v2=");
            char *end = strchr(start, ';');
            if (end) {
                *end = '\0';
                lua_pushstring(L, start);
                *end = ';';
            } else {
                lua_pushstring(L, start);
            }
        } else {
            lua_pushstring(L, captured_cookie_value);
        }
    } else {
        lua_pushnil(L);
    }

    JS_FreeContext(ctx);
    JS_FreeRuntime(rt);
    
    return 1;
}

static const struct luaL_Reg quickjs_lib[] = {
    {"eval", l_quickjs_eval},
    {NULL, NULL}
};

int luaopen_quickjs(lua_State *L) {
    luaL_newlib(L, quickjs_lib);
    return 1;
}